#!/usr/bin/env python3
"""Plot the exact rectangular nanopillar geometry from the released CSV."""

from pathlib import Path
import argparse
import csv
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle


def load_parameters(path: Path) -> dict[str, float | str]:
    with path.open("r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 1:
        raise ValueError("Expected exactly one nanopillar parameter row.")

    row = rows[0]
    numeric_keys = (
        "period_x_nm",
        "period_y_nm",
        "width_x_nm",
        "width_y_nm",
        "height_nm",
        "substrate_thickness_nm",
    )
    for key in numeric_keys:
        row[key] = float(row[key])
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--file",
        type=Path,
        default=Path(
            "data/single_layer/single_layer_nanopillar_parameters.csv"
        ),
    )
    parser.add_argument("--view", choices=("top", "xz", "yz"), default="top")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("single_layer_nanopillar_geometry.pdf"),
    )
    args = parser.parse_args()

    p = load_parameters(args.file)

    px = p["period_x_nm"]
    py = p["period_y_nm"]
    wx = p["width_x_nm"]
    wy = p["width_y_nm"]
    h = p["height_nm"]

    fig, ax = plt.subplots(figsize=(4.8, 4.0))

    if args.view == "top":
        rect = Rectangle((-wx / 2, -wy / 2), wx, wy)
        ax.add_patch(rect)
        ax.set_xlim(-px / 2, px / 2)
        ax.set_ylim(-py / 2, py / 2)
        ax.set_xlabel("x (nm)")
        ax.set_ylabel("y (nm)")
    elif args.view == "xz":
        rect = Rectangle((-wx / 2, 0), wx, h)
        ax.add_patch(rect)
        ax.set_xlim(-px / 2, px / 2)
        ax.set_ylim(0, h)
        ax.set_xlabel("x (nm)")
        ax.set_ylabel("z (nm)")
    else:
        rect = Rectangle((-wy / 2, 0), wy, h)
        ax.add_patch(rect)
        ax.set_xlim(-py / 2, py / 2)
        ax.set_ylim(0, h)
        ax.set_xlabel("y (nm)")
        ax.set_ylabel("z (nm)")

    ax.set_aspect("equal")
    fig.tight_layout()
    fig.savefig(args.output, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved figure: {args.output}")


if __name__ == "__main__":
    main()
