#!/usr/bin/env python3
"""Plot cross-sections of the five-layer constrained QWP structure."""

from pathlib import Path
import argparse
import numpy as np
import matplotlib.pyplot as plt

SHAPE = (11, 11, 31)
LX_UM = 0.2
LY_UM = 0.2
LZ_UM = 0.6


def load_txt_slices(path: Path) -> np.ndarray:
    stacked = np.loadtxt(path, comments="#")
    expected_shape = (SHAPE[2] * SHAPE[1], SHAPE[0])
    if stacked.shape != expected_shape:
        raise ValueError(
            f"Expected stacked TXT shape {expected_shape}, got {stacked.shape}."
        )
    slices_zyx = stacked.reshape(SHAPE[2], SHAPE[1], SHAPE[0], order="C")
    return np.transpose(slices_zyx, (2, 1, 0))


def load_structure(path: Path) -> np.ndarray:
    if path.suffix.lower() == ".npy":
        structure = np.load(path, allow_pickle=False)
        if structure.shape == (np.prod(SHAPE),):
            structure = structure.reshape(SHAPE, order="C")
    elif path.suffix.lower() == ".txt":
        structure = load_txt_slices(path)
    else:
        raise ValueError("The input file must be .npy or .txt.")

    if structure.shape != SHAPE:
        raise ValueError(f"Expected shape {SHAPE}, got {structure.shape}.")
    return structure


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--file",
        type=Path,
        default=Path(
            "data/five_layer/five_layer_qwp_binary_structure_3d.npy"
        ),
    )
    parser.add_argument("--axis", choices=("x", "y", "z"), default="z")
    parser.add_argument("--index", type=int, default=None)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("five_layer_qwp_cross_section.pdf"),
    )
    args = parser.parse_args()

    structure = load_structure(args.file)
    axis_number = {"x": 0, "y": 1, "z": 2}[args.axis]
    index = structure.shape[axis_number] // 2 if args.index is None else args.index

    if not 0 <= index < structure.shape[axis_number]:
        raise IndexError(
            f"Index {index} is outside 0 to {structure.shape[axis_number] - 1}."
        )

    section = np.take(structure, index, axis=axis_number)

    if args.axis == "z":
        image_data = section.T
        extent = [-LX_UM / 2, LX_UM / 2, -LY_UM / 2, LY_UM / 2]
        xlabel, ylabel = "x (µm)", "y (µm)"
    elif args.axis == "y":
        image_data = section.T
        extent = [-LX_UM / 2, LX_UM / 2, -LZ_UM / 2, LZ_UM / 2]
        xlabel, ylabel = "x (µm)", "z (µm)"
    else:
        image_data = section.T
        extent = [-LY_UM / 2, LY_UM / 2, -LZ_UM / 2, LZ_UM / 2]
        xlabel, ylabel = "y (µm)", "z (µm)"

    fig, ax = plt.subplots(figsize=(4.8, 4.0))
    image = ax.imshow(
        1.0 - image_data,
        origin="lower",
        interpolation="nearest",
        aspect="equal",
        extent=extent,
        vmin=0,
        vmax=1,
        cmap="gray",
    )
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    colorbar = fig.colorbar(image, ax=ax)
    colorbar.set_label("1 - material density")
    fig.tight_layout()
    fig.savefig(args.output, bbox_inches="tight")
    plt.close(fig)

    print(f"Loaded structure shape: {structure.shape}")
    print(f"Saved figure: {args.output}")


if __name__ == "__main__":
    main()
